print("hello from lua!")

--print_orig = print

--[[print = function(args)
	print_orig(debug.getinfo(1)..args)
end]]
objaccessormetatable = {
	__index = function(self,prop)
		return gm_var_get(self.___getid(),prop)
	end,
	__newindex = function(self,prop,val)
		gm_var_set(self.___getid(),prop,val)
	end
}
gmglobal={

}
globalmeta = {
	__index = function(self,prop)
		return gm_global_get(prop)
	end,
	__newindex = function(self,prop,val)
		gm_global_set(prop,val)
	end
}
setmetatable(gmglobal,globalmeta)



ISAAC = {
	___getid = function()
		return gmglobal.me
	end
}
--log(gmglobal.me)

setmetatable(ISAAC,objaccessormetatable)

globalfunctiontable = {}

function call_func(functionName,self,args,args2)
	globalfunctiontable[functionName](self,args,args2)
end
function encode_table(theTable)
	for k,v in pairs(theTable) do
		if(type(v) == 'function') then
			add = 0
			while(globalfunctiontable[k..tostring(add)] ~= nil) do
				add = add + 1
			end
			globalfunctiontable[k..tostring(add)] = v
			theTable[k] = "@"..k..tostring(add) --put it into the global function table with an @ (we use the @ to signify if a string is a function or not)
		end
		if(type(v) == 'table') then
			v = encode_table(v) --go recursive
		end
	end
	return theTable
end

function decode_table(theTable)
	for k,v in pairs(theTable) do
		if(type(v) == 'string') then
			if(v:sub(1,1) == "@") then
				theTable[k] = globalfunctiontable[v:sub(2,#v-1)]
			end
		end
		if(type(v) == 'table') then
			v = decode_table(v)
		end
	end
	return theTable
end

print("hello from lua + traceback")

a = {
	onstep = function()
		log("IM WORKING!!!!")
		ISAAC.x = ISAAC.x + 1
		--log("trolld");
	end,
	ondraw = function() 
		print("im shittin")
	end,
	--myhooks: {onstep: true},
	name= "Annoying Parasol but lua",
	description= "The annoying parasol recoded in lua",
	tooltip= "Well, works as always.",
	sprite= s_yukari,
	quality= 7,
	usage= 1,
	initiallyunlocked= true,
	
	--quality goes from 1 to 6 (this is also the buy/sell value of items)
}

--itemgen(encode_table(a),1)

--log(ISAAC.testy)



--log(a)